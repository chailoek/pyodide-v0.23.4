Authors
=======

* Ionel Cristian Mărieș - https://blog.ionelmc.ro
* Arcadiy Ivanov - https://github.com/arcivanov
* Beckjake - https://github.com/beckjake
* DRayX - https://github.com/DRayX
* Jason Madden - https://github.com/jamadden
* Jon Dufresne - https://github.com/jdufresne
* Elliott Sales de Andrade - https://github.com/QuLogic
* Victor Stinner - https://github.com/vstinner
* Guido Imperiale - https://github.com/crusaderky
* Ivanq - https://github.com/imachug
